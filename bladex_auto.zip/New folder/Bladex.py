import tkinter as tk
from os import path
from glob import glob  
import pandas as pd
import numpy as np
from openpyxl import load_workbook

pd.reset_option('display.float_format')
pd.options.display.float_format = '{:.2f}'.format
#window creating
window = tk.Tk() 
window.title('Bladex')
window.geometry('400x150')  # 这里的乘是小x

var_path = tk.StringVar()
entry_path = tk.Entry(window, textvariable=var_path, font=('Arial', 14))
entry_path.place(x=100,y=90)

# var_path2 = tk.StringVar()
# entry_path2 = tk.Entry(window, textvariable=var_path2, font=('Arial', 14))
# entry_path2.place(x=100,y=50)


def reporting():
    path = var_path.get()
    # path2 = var_path2.get()

    # df1 = df_ffca[df_ffca['Sales Invoiced Amount'] != 0]

    df_ffca = pd.read_excel(path + '/FFCA.xlsx', engine='openpyxl')
    df_bladex = pd.read_excel(path + '/bladex input.xlsx', sheet_name='MMI', engine='openpyxl')
    df_ecuatorian = pd.read_excel(path + '/bladex input.xlsx', sheet_name='ecuatorian CPs', engine='openpyxl')
    df_bolivian = pd.read_excel(path + '/bladex input.xlsx', sheet_name='Bolivian CPs', engine='openpyxl')

    cols_ffca = ['Purchase Assignment ID', 'Sales Invoiced Amount', 'Sales Settled Amount' ,'Accounts Receivable', 'Inventory Status'] 
    df1 = df_ffca[cols_ffca]
    df2 = pd.merge(df1, df_bladex, left_on='Purchase Assignment ID', right_on= 'P ASSIGNMENT', how='right')
    df2 = df2.drop(columns=['Purchase Assignment ID'])
    df2_x = df2[df2['TOTAL PAID QUANTITY'] == 0]
    df2 = df2[df2['TOTAL PAID QUANTITY'] != 0]


    #ecuatorian
    df3 = pd.merge(df2, df_ecuatorian, left_on='COUNTERPARTY', right_on= 'Counterparty of Purchase', how='inner')
    df_ecuatorian_SI = df3[df3['Sales Invoiced Amount'] != 0 ]
    df_ecuatorian_exclu1 = df_ecuatorian_SI[df_ecuatorian_SI['Accounts Receivable'] == 0 ]
    # df_ecuatorian_exclu2 = df3[df3['TOTAL PAID QUANTITY'] == 0]


    #bolivian
    df4 = pd.merge(df2, df_bolivian, left_on='COUNTERPARTY', right_on= 'Counterparty of Purchase', how='inner')
    df_bolivian_SI = df4[df4['Sales Invoiced Amount'] != 0 ]
    df_bolivian_exclu1 = df_bolivian_SI[df_bolivian_SI['Accounts Receivable'] == 0 ]
    # df_bolivian_exclu2 = df4[df4['TOTAL PAID QUANTITY'] == 0]

    df_bolivian_exclu3_transit = df4[df4['Inventory Status'] == 'In-Transit']
    df_bolivian_exclu3_delivered = df4[df4['Inventory Status'] == 'Delivered']
    df_bolivian_exclu3_ConcsBB = pd.concat([df_bolivian_exclu3_transit, df_bolivian_exclu3_delivered])

    df_ecuatorian_remaining = pd.concat([df3, df_ecuatorian_exclu1, df_ecuatorian_exclu1]).drop_duplicates(keep=False)
    df_bolivian_remaining = pd.concat([df4, df_bolivian_exclu1, df_bolivian_exclu1, df_bolivian_exclu1]).drop_duplicates(keep=False)
    df_bolivian_remaining = pd.concat([df_bolivian_remaining, df_bolivian_exclu3_ConcsBB, df_bolivian_exclu3_ConcsBB]).drop_duplicates(keep=False)
    df_remaining = pd.concat([df_ecuatorian_remaining, df_bolivian_remaining])
    df_exclu = pd.concat([df_ecuatorian_exclu1, df_bolivian_exclu1])
    df_exclu = pd.concat([df_exclu, df2_x])


    df_remaining.to_excel(path + '/new_bladex.xlsx')

    writer = pd.ExcelWriter(path + '/new_bladex.xlsx', engine='xlsxwriter')


    df_remaining = df_remaining.loc[:,[ 'P ASSIGNMENT', 'AMOUNT', 'FINANCED QUANTITY',
       'COMMENTS', 'COMMODITY', 'QUANTITY', 'TOTAL PAID QUANTITY',
       'AUTHORIZED PAID QUANTITY', 'FINANCED QUANTITY.1', 'UOM',
       'COUNTERPARTY', 'INV STATUS']]
    df_exclu = df_exclu.loc[:,[ 'P ASSIGNMENT', 'AMOUNT', 'FINANCED QUANTITY',
       'COMMENTS', 'COMMODITY', 'QUANTITY', 'TOTAL PAID QUANTITY',
       'AUTHORIZED PAID QUANTITY', 'FINANCED QUANTITY.1', 'UOM',
       'COUNTERPARTY', 'INV STATUS']]
    df_bolivian_exclu3_ConcsBB = df_bolivian_exclu3_ConcsBB.loc[:,[ 'P ASSIGNMENT', 'AMOUNT', 'FINANCED QUANTITY',
       'COMMENTS', 'COMMODITY', 'QUANTITY', 'TOTAL PAID QUANTITY',
       'AUTHORIZED PAID QUANTITY', 'FINANCED QUANTITY.1', 'UOM',
       'COUNTERPARTY', 'INV STATUS']]
    
    df_remaining.to_excel(excel_writer=writer, sheet_name='Remaining', index=False)
    df_exclu.to_excel(excel_writer=writer, sheet_name='Exclusions', index=False)
    df_bolivian_exclu3_ConcsBB.to_excel(excel_writer=writer, sheet_name='ConcsBB',index=False)

    worksheet1 = writer.sheets['Remaining']
    worksheet2 = writer.sheets['Exclusions']
    worksheet3 = writer.sheets['ConcsBB']

    # adjust the column width to fit the longest string in the column
    for i, col in enumerate(df_remaining.columns):
        column_len = df_remaining[col].astype(str).str.len().max()
        column_width = max(column_len, len(col)) + 2
        worksheet1.set_column(i, i, column_width)

    # adjust the column width to fit the longest string in the column
    for i, col in enumerate(df_exclu.columns):
        column_len = df_exclu[col].astype(str).str.len().max()
        column_width = max(column_len, len(col)) + 2
        worksheet2.set_column(i, i, column_width)

    # adjust the column width to fit the longest string in the column
    for i, col in enumerate(df_bolivian_exclu3_ConcsBB.columns):
        column_len = df_bolivian_exclu3_ConcsBB[col].astype(str).str.len().max()
        column_width = max(column_len, len(col)) + 2
        worksheet3.set_column(i, i, column_width)

    # save and close the excel file
    writer.save()
    writer.close()

# setting button
btn_print = tk.Button(window, text='Report', command=reporting)
btn_print.place(x=50, y=50)

    

window.mainloop()